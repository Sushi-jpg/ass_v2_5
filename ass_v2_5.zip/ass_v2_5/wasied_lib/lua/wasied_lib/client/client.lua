--[[ Responsives functions ]]--
function WasiedLib.RespX(x)
    return x/1920*ScrW()
end

function WasiedLib.RespY(y)
    return y/1080*ScrH()
end